# TSP问题的求解方法


*  **data**.C-TSP问题中国34个城市的经纬度。
*  **ga**.遗传算法求解TSP问题代码。

[Blog:http://zh.5long.me](http://zh.5long.me)

TSP问题博文链接：<http://zh.5long.me/2015/genetic-algorithm-on-tsp/>

##License

tsp is published under the MIT License (MIT) License. See the LICENSE file for more.
