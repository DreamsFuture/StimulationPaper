### 0.4.0
- Tests running on python{2|3|pypy}
- fix auto method to return updates (#16)
